class WordAnalogy:
    def run(self, input):
        return "Your Answer"